This is a trial run of the first monster in a series of mods I would like to make, so feel free to leave any feedback you have for me!

The image for the whelpling and all future girls come from Kanel_Art on Patreon, or @BurnRev on Twitter